import java.util.*;
public class palind {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int num=sc.nextInt();
        double n=Math.log10(num)+1;
        System.out.println((int)n);
        
    }
}
