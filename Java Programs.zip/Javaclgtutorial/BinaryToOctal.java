import java.util.*;

public class BinaryToOctal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int num = sc.nextInt();
        
        while(num>=0)
        {
            int rev=0;
            int rem=num/10;
            // int rev=rev*10+rem;
            num=num/10;
            if (rem>=3)
            {
                
            }

        }
    }
}
